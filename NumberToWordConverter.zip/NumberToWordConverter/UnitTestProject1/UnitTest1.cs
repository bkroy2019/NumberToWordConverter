﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumberToWordLibrary;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void NumberToWordTest_21()
        {
            var word = NumberToWordConversion.ConvertNumberToWords("21");
            Assert.IsTrue(word == "Twenty One");
        }

        [TestMethod]
        public void NumberToWordTest_105()
        {
            var word = NumberToWordConversion.ConvertNumberToWords("105");
            Assert.IsTrue(word == "One Hundred Five");
        }


        [TestMethod]
        public void NumberToWordTest_56945781()
        {
            var word = NumberToWordConversion.ConvertNumberToWords("56945781");
            Assert.IsTrue(word == "Fifty Six Million Nine Hundred Fourty Five Thousand Seven Hundred Eighty One");
        }


        [TestMethod]
        public void NumberToWordTest_999999999()
        {
            var word = NumberToWordConversion.ConvertNumberToWords("999999999");
            Assert.IsTrue(word == "Nine Hundred Ninety Nine Million Nine Hundred Ninety Nine Thousand Nine Hundred Ninety Nine");
        }
    }
}
